<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
		<meta name="description" content="飘飞的心灵，祝愿你我，在这个繁忙的世界不迷失自己。">
		<meta name="author" content="梁峻荣">

		<title>后台管理系统-文章分类列表</title>

		<link rel="shortcut icon" type="image/x-icon" href="/myWeb/Public/Image/icon(32).ico" />
		<link href="/myWeb/Public/Css/bootstrap.min.css" rel="stylesheet">
		<link href="/myWeb/Public/Css/page.css" rel="stylesheet" />
	</head>

	<body>
		<div class="container">
			<div class="col-md-12 column">
				<nav class="navbar navbar-default" role="navigation">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">切换导航</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	<a class="navbar-brand" href="/myWeb/index.php/Admin/index">梁峻荣的网站-后台管理</a></div>
	
	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		<ul class="nav navbar-nav navbar-right">
			<li>
				<a target="_blank" href="/myWeb/index.php/Home/Index/index">网站首页</a>
			</li>
			<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['username']; ?>
					<strong class="caret"></strong>
				</a>
			<ul class="dropdown-menu">
				<li>
					<a href="/myWeb/index.php/Admin/About/index">
						<span class="glyphicon glyphicon-info-sign"></span> 个人资料
					</a>
				</li>
				<li class="divider"></li>
				<li>
					<a href="/myWeb/index.php/Admin/Admin/logout">
						<span class="glyphicon glyphicon-off"></span> 退出
					</a>
				</li>
			</ul>
			</li>
		</ul>
	</div>
</nav>
				<div class="row clearfix">
					<div class="col-md-3 column">
	<div id="list" class="list-group">
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Index/index">首页</a>
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Category/category_list">文章分类管理</a>
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Article/article_list">文章管理</a>
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Admin/admin_list">管理员管理</a>
		
		<!-- 暂未实现功能 -->
		<a class="list-group-item btn btn-default disabled active" href="#">————————</a>
		<a class="list-group-item btn btn-default disabled" href="#">留言管理</a>
		<a class="list-group-item btn btn-default disabled" href="#">相册管理</a>
		<a class="list-group-item btn btn-default disabled" href="#">文章评论管理</a>
	</div>
	
</div>

					<div class="col-md-9 column">
						<ul class="breadcrumb">
							<li>
								<a href="/myWeb/index.php/Admin/Index/index">首页</a>
							</li>
							<li>
								<a href="/myWeb/index.php/Admin/Category/category_list">文章分类管理</a>
							</li>
							<li class="active">
								文章分类列表
							</li>
						</ul>
						<form name="myform" id="myform" action="/myWeb/index.php/Admin/Category/category_sort" method="post">
			                <div>
			                    <div>
			                        <a class="btn btn-primary" href="/myWeb/index.php/Admin/Category/category_add">
			                        	<span class="glyphicon glyphicon-plus"></span> 新增文章分类
			                        </a>
			                        <a id="updateOrd" href="">
			                        	<input class="btn btn-primary" type="submit" value="更新排序" />
			                        </a>
			                        <p></p>
			                    </div>
			                </div>
			                <div class="table-responsive">
			                    <table class="table table-bordered text-center">
									<thead>
										<tr>
											<th class="text-center" width="25%">
												排序
											</th>
											<th class="text-center">
												ID
											</th>
											<th class="text-center">
												分类名称
											</th>
											<th class="text-center">
												操作
											</th>
										</tr>
									</thead>
									<tbody>
										<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
											<td>
												<input class="btn btn-default" type="text" name="<?php echo ($vo["id"]); ?>" value="<?php echo ($vo["sort"]); ?>">
											</td>
											<td>
												<?php echo ($vo["id"]); ?>
											</td>
											<td>
												<a target="_blank" href="#" title="<?php echo ($vo["categoryname"]); ?>"><?php echo ($vo["categoryname"]); ?></a>
											</td>
											<td>
												<a href="/myWeb/index.php/Admin/Category/category_edit/id/<?php echo ($vo["id"]); ?>">修改</a>
			                                	<a onclick="return confirm('你要删除该分类吗？');" href="/myWeb/index.php/Admin/Category/category_delete/id/<?php echo ($vo["id"]); ?>">删除</a>
											</td>
										</tr><?php endforeach; endif; else: echo "" ;endif; ?>
									</tbody>
								</table>
			                    <div class="list-page"><?php echo ($page); ?></div>
			                </div>
			            </form>
					</div>
				</div>
			</div>
		</div>

		<script src="/myWeb/Public/Js/jquery.min.js"></script>
		<script src="/myWeb/Public/Js/bootstrap.min.js"></script>
	</body>

</html>