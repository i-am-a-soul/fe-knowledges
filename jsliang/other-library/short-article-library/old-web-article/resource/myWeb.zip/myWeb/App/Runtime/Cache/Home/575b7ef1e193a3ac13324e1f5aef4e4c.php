<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">

	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
		<meta name="description" content="飘飞的心灵，祝愿你我，在这个繁忙的世界不迷失自己。">
		<meta name="author" content="梁峻荣">

		<title>梁峻荣的网站</title>

		<link href="/myWeb/Public/Css/bootstrap.min.css" rel="stylesheet">
		<style>
			.text-indent{
				text-indent: 2em;
			}
		</style>
	</head>

	<body>
		<div class="container">
			<div class="col-md-4">
				<!--导航栏-->
<nav class="navbar navbar-default" role="navigation">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#indexNav">
			<span class="sr-only">图标导航</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" href="/myWeb/index.php/Home/Index/index">飘飞的心灵</a>
	</div>

	<div class="collapse navbar-collapse" id="indexNav">
		<ul class="nav navbar-nav">
			<li>
				<a href="/myWeb/index.php/Home/Article/article_list">自学风暴</a>
			</li>
			<li>
				<a href="/myWeb/index.php/Home/About/index">关于网站</a>
			</li>
		</ul>
		<form class="navbar-form navbar-left" action="http://www.baidu.com/baidu" target="_blank">
			<div class="form-group">
				<input type="text" name="word">
			</div>
			<button type="submit" class="btn btn-default">搜索</button>
		</form>
		<ul class="nav navbar-nav navbar-right">
			<li>
				<a target="_blank" href="/myWeb/index.php/Admin/Login/index">网站管理</a>
			</li>
		</ul>
	</div>
</nav>
				
				<!--内容区-->
				<div class="list">
					<!-- 左 -->
					<ul>
						<?php if(is_array($categorys)): $i = 0; $__LIST__ = $categorys;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
							<a <?php if($current == $vo['id']): ?>class="btn btn-primary"<?php endif; ?> href="/myWeb/index.php/Home/Category/index/id/<?php echo ($vo["id"]); ?>"><?php echo ($vo["categoryname"]); ?></a>
						</li><?php endforeach; endif; else: echo "" ;endif; ?>
					</ul>
				</div>
					<!-- 中 -->
					<div class="thumbnail col-md-4">
						<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><a href="/myWeb/index.php/Home/Article/index/id/<?php echo ($vo["id"]); ?>">
									<img src="/myWeb<?php echo ($vo["picture"]); ?>" alt="<?php echo ($vo["title"]); ?>" />
								</a>
								<a href="/myWeb/index.php/Home/Article/index/id/<?php echo ($vo["id"]); ?>">
									<?php echo ($vo["title"]); ?>
								</a>
								<p><?php echo ($vo["description"]); ?>...</p>
								<p><?php echo (date("Y-m-d", $vo["time"])); ?></p><?php endforeach; endif; else: echo "" ;endif; ?>
						<div><?php echo ($page); ?></div>
					</div>
				<div class="col-md-4">
					<!-- 右 -->
					<div class="news">
						<ul>
							<?php if(is_array($artres)): $i = 0; $__LIST__ = $artres;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li>
								<a href="/myWeb/index.php/Home/Article/index/id/<?php echo ($vo["id"]); ?>"><?php echo ($vo["title"]); ?></a>
							</li><?php endforeach; endif; else: echo "" ;endif; ?>
						</ul>
					</div>
				</div>
				<!-- 文章详细信息 -->
				<div class="content">
					<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="thumbnail col-md-3">
							<a href="/myWeb/index.php/Home/Article/index/id/<?php echo ($vo["id"]); ?>">
								<img src="/myWeb<?php echo ($vo["picture"]); ?>" alt="<?php echo ($vo["title"]); ?>" />
							</a>
							<a href="/myWeb/index.php/Home/Article/index/id/<?php echo ($vo["id"]); ?>">
								<?php echo ($vo["title"]); ?>
							</a>
							<p><?php echo ($vo["description"]); ?>...</p>
							<p><?php echo (date("Y-m-d", $vo["time"])); ?></p>
						</div><?php endforeach; endif; else: echo "" ;endif; ?>
					<div><?php echo ($page); ?></div>
				</div>
				<!--底部-->
				<!--底部-->
<div class="modal-footer col-md-12">
	<p class="text-center">
		Copyright© 2016 梁峻荣的网站-飘飞的心灵 All Rights Reserved
		</p>
	<p class="icp text-center">
		<a href="http://www.miitbeian.gov.cn">粤ICP备16084737号-1</a>
	</p>
</div>

			</div>
		</div>

		<script src="/myWeb/Public/Js/jquery.min.js"></script>
		<script src="/myWeb/Public/Js/bootstrap.min.js"></script>

	</body>

</html>