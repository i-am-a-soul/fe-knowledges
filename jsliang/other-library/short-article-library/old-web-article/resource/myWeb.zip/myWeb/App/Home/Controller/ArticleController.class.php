<?php
namespace Home\Controller;
use Think\Controller;
class ArticleController extends ArticleCommonController {
    //文章首页
	public function article_list(){
    	//最新发表文章
    	$this->article_news();
    	//最新文章
    	$this->article_current();
    	//加载完毕，展示html页面
    	$this->display();
    }
	
	//【文章首页】最新文章列表
	public function article_news(){
		$artres = D('article')->order('time desc')->limit(8)->select();
		$this->assign('artres', $artres);
	}
    
	//【文章首页】最新文章
    public function article_current(){
    	$article= D('article'); // 实例化User对象
    	$count=$article->count();// 查询满足要求的总记录数
    	$Page= new \Think\Page($count,10);//
    	$show = $Page->show();// 
    	$list = $article->order('time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
    	$this->assign('page',$show);// 赋值分页输出
    	$this->assign('list',$list);// 赋值数据集
    }
    
	//文章分类页
	public function article_category_list(){
		//文章分页
 		$this->article_category_page();
 		
 		$categoryname = D('category')->find(I('id'));
 		$this->assign('categoryname', $categoryname);
 		
    	//加载完毕，展示html页面
    	$this->display();
	}
	
	//【文章分类页】文章分类页分类
	public function article_category_page(){
		//当前分类的文章列表分页
		$categoryid=I('id');
    	$article= D('article'); // 实例化User对象
    	$count=$article->where(array('categoryid'=>$categoryid))->count();// 查询满足要求的总记录数
    	$Page= new \Think\Page($count,10);//
    	$show       = $Page->show();// 
    	$list = $article->where(array('categoryid'=>$categoryid))->order('time desc')->limit($Page->firstRow.','.$Page->listRows)->select();
    	$this->assign('page',$show);// 赋值分页输出
    	$this->assign('list',$list);// 赋值数据集
	}
    
	//文章详细页
	public function article_detail(){
		//寻找article表里的id（与用户提交的相同），并分配出去
		$arts = D('article')->find(I('id'));
        $this->assign('arts', $arts);
        //传递article表中的categoryid字段，找到对应的文章分类名称
        $this->categoryname($arts['categoryid']);
        //传递用户的id，展示上一篇、下一篇
        $this->change_page(I('id'));
    	$this->display();
	}
    
    //【文章详细页】寻找文章分类名称
    public function categoryname($categoryid){
    	$categorys = D('category')->find($categoryid);
    	$this->assign('categoryname', $categorys['categoryname']);
    }
    
    //【文章详细页】上一篇、下一篇
    public function change_page($id){
    	$article = D('article');
    	$articles = $article->find($id);
    	$categoryid = $articles['categoryid'];
    	$prevs = $article->where('id<'.$id)->where(array('categoryid'=>$categoryid))->order('id desc')->find();
    	$nexts = $article->where('id>'.$id)->where(array('categoryid'=>$categoryid))->order('id asc')->find();
    	$this->assign('prevs', $prevs);
    	$this->assign('nexts', $nexts);
    }
}