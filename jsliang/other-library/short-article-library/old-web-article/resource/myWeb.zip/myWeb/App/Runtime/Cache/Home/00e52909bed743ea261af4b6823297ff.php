<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">

	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
		<meta name="description" content="飘飞的心灵，祝愿你我，在这个繁忙的世界不迷失自己。">
		<meta name="author" content="梁峻荣">

		<title>梁峻荣的网站</title>

		<link rel="shortcut icon" type="image/x-icon" href="/myWeb/Public/Image/icon(32).ico" />
		<link href="/myWeb/Public/Css/bootstrap.min.css" rel="stylesheet" />
		<link href="/myWeb/Public/Css/common.css" rel="stylesheet" />
		<link href="/myWeb/Public/Css/page.css" rel="stylesheet" />
	</head>

	<body>
		<div class="container">
			<div class="row">
				<!--导航栏-->
<nav class="navbar navbar-default" role="navigation">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#indexNav">
			<span class="sr-only">图标导航</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" href="/myWeb/index.php/Home/Index/index">飘飞的心灵</a>
	</div>

	<div class="collapse navbar-collapse" id="indexNav">
		<ul class="nav navbar-nav">
			<li>
				<a href="/myWeb/index.php/Home/Article/article_list">自学风暴</a>
			</li>
			<li>
				<a href="/myWeb/index.php/Home/About/index">自学旅途</a>
			</li>
		</ul>
		<form class="navbar-form navbar-left" action="http://www.baidu.com/baidu" target="_blank">
			<div class="form-group">
				<input type="text" name="word">
			</div>
			<button type="submit" class="btn btn-default">搜索</button>
		</form>
	</div>
</nav>
				
				<!--内容区-->
				<!--内容1-->
				<div class="col-md-12 text-center text-info">
					<h3>飘飞的心灵——活得潇洒</h3>
					<hr />
				</div>
				<div class="col-md-12">
					<div class="col-md-2 text-center">
						<div class="thumbnail">
							<p class="text-info">心灵细语</p>
							<img class="img-circle" alt="200x111" src="/myWeb/Public/image/7.jpg" />
							<div class="caption text-center">
								<h4>人生三愿</h4>
								<p>吃得下饭</p>
								<p>睡得着觉</p>
								<p>笑得出来</p>
								<p>★<a target="_blank" href="/myWeb/index.php/Admin/Login/index"><span class="glyphicon glyphicon-star"></span></a>★★</p>
							</div>
						</div>
					</div>
					<div class="col-md-8">
						<h3 class="text-center text-info">最新文章</h3>
						<hr />
						<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="col-md-12 column thumbnail">
								<div class="col-md-8">
									<br/>
									<a class="text-info" href="/myWeb/index.php/Home/Article/article_detail/id/<?php echo ($vo["id"]); ?>"><?php echo ($vo["title"]); ?></a>
									<p class="text-indent"><?php echo ($vo["description"]); ?></p>
									<p class="text-right">——<?php echo (date("Y-m-d", $vo["time"])); ?></p>
								</div>	
								<div class="col-md-4">
									<a href="/myWeb/index.php/Home/Article/article_detail/id/<?php echo ($vo["id"]); ?>">
										<img class="img-responsive img-rounded" src="/myWeb<?php echo ($vo["picture"]); ?>" alt="<?php echo ($vo["title"]); ?>" />
									</a>
								</div>			
							</div><?php endforeach; endif; else: echo "" ;endif; ?>
						<div class="list-page"><?php echo ($page); ?></div>
					</div>
					<div class="col-md-2 text-center">
						<div class="thumbnail">
							<p class="text-info">心灵细语</p>
							<img class="img-circle" alt="200x111" src="/myWeb/Public/image/8.jpg" />
							<div class="caption">
								<h4>人生四然</h4>
								<p>来是偶然</p>
								<p>去是必然</p>
								<p>尽其当然</p>
								<p>顺其自然</p>
							</div>
						</div>
					</div>
				</div>
				<!--底部-->
				<!--底部-->
<div class="col-md-12">
	<br/>
	<p class="text-center">
		Copyright© 2016 梁峻荣的网站-飘飞的心灵 All Rights Reserved
	</p>
	<p class="icp text-center">
		<a target="_blank" href="http://www.miitbeian.gov.cn">粤ICP备16084737号-1</a>
	</p>
</div>

			</div>
		</div>

		<script src="/myWeb/Public/Js/jquery.min.js"></script>
		<script src="/myWeb/Public/Js/bootstrap.min.js"></script>

	</body>

</html>