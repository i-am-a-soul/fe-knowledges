<?php
namespace Admin\Controller;
use Think\Controller;
class CategoryController extends CommonController {
    public function category_list(){
    	$category = D('category');
    	
    	//分页
    	$count = $category->count();	//查询满足要求的总记录数
    	$Page = new \Think\Page($count, 10);
    	$show = $Page->show();
    	$list = $category->order('sort asc')->limit($Page->firstRow.','.$Page->listRows)->select();
    	$this->assign('list', $list);	//赋值数据集
		$this->assign('page', $show);	//赋值分页输出
    	
		//排序
		//$categoryres = $category->order('sort asc')->select();
    	//$this->assign('categoryres', $categoryres);
		
    	$this->display();
    }
	public function category_add(){
    	$category = D('category');
    	if(IS_POST){
    		$data['categoryname'] = I('categoryname');
            if($category->create($data)){
                if($category->add()){
                    $this->success('添加分类成功！',U('category_list'));
                }else{
                    $this->error('添加分类失败！');
                }
            }else{
                $this->error($category->getError());
            }

            return;
    	}
        $this->display();
    }
 	public function category_edit(){
    	$category = D('category');
    	if(IS_POST){
    		$data['categoryname'] = I('categoryname');
    		$data['id'] = I('id');
    		if($category->create($data)){
    			$save = $category->save();
    			if($save !== false){
    				$this->success('修改分类成功！', U('category_list'));
    			}else{
    				$this->error('修改分类失败！');
    			}
    		}else{
    			$this->error($category->getError());
    		}
    		return;
    	}
    	$categorys = $category->find(I('id'));
    	$this->assign('categorys', $categorys);
 		$this->display();
    }
 	public function category_delete(){
    	$category = D('category');
    	if($category->delete(I('id'))){
    		$this->success('删除分类成功！', U('category_list'));
    	}else{
    		$this->error('删除分类失败！');
    	}
    }
	public function category_sort(){
    	$category = D('category');
    	foreach ($_POST as $id => $sort){
    		$category->where(array('id'=>$id))->setField('sort', $sort);
    	}
    	$this->success('排序成功！', U('category_list'));
    }
}