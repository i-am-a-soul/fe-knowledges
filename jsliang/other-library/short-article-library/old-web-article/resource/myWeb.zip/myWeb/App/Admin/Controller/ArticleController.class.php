<?php
namespace Admin\Controller;
use Think\Controller;
class ArticleController extends CommonController {
    public function article_list(){
    	$article = D('ArticleView');
    	
    	//分页
    	$count = $article->count();	//查询满足要求的总记录数
    	$Page = new \Think\Page($count, 10);
    	$show = $Page->show();
    	$list = $article->order('id desc')->limit($Page->firstRow.','.$Page->listRows)->select();
    	$this->assign('list', $list);	//赋值数据集
		$this->assign('page', $show);	//赋值分页输出
    	
		//排序
		//$articleres = $article->order('sort asc')->select();
    	//$this->assign('articleres', $articleres);
		
    	$this->display();
    }
	public function article_add(){
    	$article = D('article');
    	if(IS_POST){
    		$data['title'] = I('title');
    		$data['content'] = I('content');
    		$data['description'] = I('description');
    		$data['categoryid'] = I('categoryid');
    		$data['time']=time();
    		//图片上传
    		if($_FILES['picture']['tmp_name'] != ''){
    			$upload = new \Think\Upload();	//实例化上传类
    			$upload->maxSize = 3145728;		//设置附件上传大小
    			$upload->exts = array('jpg', 'png', 'gif', 'jpeg');		//设置附件上传类型
    			$upload->savePath = '/Public/Uploads/';	//设置附件上传（子）目录
    			$upload->rootPath = './';					//设置附件上传目录
    			$info = $upload->uploadOne($_FILES['picture']);		//上传单个文件
    			if(!$info){
    				//上传错误，提示信息
    				$this->error($upload->getError());
    			}else{
    				//上传成功，保存文件路径到picture
    				$data['picture'] = $info['savepath'].$info['savename'];
    			}
    		}
            if($article->create($data)){
                if($article->add()){
                    $this->success('添加文章成功！',U('article_list'));
                }else{
                    $this->error('添加文章失败！');
                }
            }else{
                $this->error($article->getError());
            }
            return;
    	}
    	
    	$categoryres = D('category')->select();
    	$this->assign('categoryres', $categoryres);
    	
        $this->display();
    }
 	public function article_edit(){
    	$article = D('article');
    	if(IS_POST){
    		$data['title'] = I('title');
    		$data['content'] = I('content');
    		$data['description'] = I('description');
    		$data['categoryid'] = I('categoryid');
    		$data['id']=I('id');
    		if($_FILES['picture']['tmp_name']!=''){
                $upload = new \Think\Upload();// 实例化上传类
                $upload->maxSize   =     3145728 ;// 设置附件上传大小
                $upload->exts      =     array('jpg', 'gif', 'png', 'jpeg');// 设置附件上传类型
                $upload->savePath  =      './Public/Uploads/'; // 设置附件上传目录
                $upload->rootPath  =      './'; // 设置附件上传目录
                $info   =   $upload->uploadOne($_FILES['picture']);
                if(!$info){
                    $this->error($upload->getError());
                }else{
                   $data['picture']=$info['savepath'].$info['savename'];
                }
            }
    		if($article->create($data)){
    			$save = $article->save();
    			if($save !== false){
    				$this->success('修改文章成功！', U('article_list'));
    			}else{
    				$this->error('修改文章失败！');
    			}
    		}else{
    			$this->error($article->getError());
    		}
    		return;
    	}
    	
    	$articles = $article->find(I('id'));
    	$this->assign('articles', $articles);
    	
    	$categoryres = D('category')->select();
    	$this->assign('categoryres', $categoryres);
 		
    	$this->display();
    }
 	public function article_delete(){
    	$article = D('article');
    	if($article->delete(I('id'))){
    		$this->success('删除文章成功！', U('article_list'));
    	}else{
    		$this->error('删除文章失败！');
    	}
    }
}