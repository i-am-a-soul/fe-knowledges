<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">

	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
		<meta name="description" content="飘飞的心灵，祝愿你我，在这个繁忙的世界不迷失自己。">
		<meta name="author" content="梁峻荣">

		<title>梁峻荣的网站</title>

		<link href="/myWeb/Public/Css/bootstrap.min.css" rel="stylesheet">
		<link href="/myWeb/Public/Css/common.css" rel="stylesheet" />
		<link href="/myWeb/Public/Css/page.css" rel="stylesheet" />
	</head>

	<body>
		<div class="container">
			<div class="row">
				<!--导航栏-->
<nav class="navbar navbar-default" role="navigation">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#indexNav">
			<span class="sr-only">图标导航</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" href="/myWeb/index.php/Home/Index/index">飘飞的心灵</a>
	</div>

	<div class="collapse navbar-collapse" id="indexNav">
		<ul class="nav navbar-nav">
			<li>
				<a href="/myWeb/index.php/Home/Article/article_list">自学风暴</a>
			</li>
			<li>
				<a href="/myWeb/index.php/Home/About/index">关于网站</a>
			</li>
		</ul>
		<form class="navbar-form navbar-left" action="http://www.baidu.com/baidu" target="_blank">
			<div class="form-group">
				<input type="text" name="word">
			</div>
			<button type="submit" class="btn btn-default">搜索</button>
		</form>
		<ul class="nav navbar-nav navbar-right">
			<li>
				<a target="_blank" href="/myWeb/index.php/Admin/Login/index">
					<span class="glyphicon glyphicon-star"></span>
					网站管理
					<span class="glyphicon glyphicon-star"></span>
				</a>
			</li>
		</ul>
	</div>
</nav>
				
				<!--内容区-->
				<div class="col-md-12 content">
					<div class="col-md-2">
						
					</div>
					<div class="col-md-8">
						<div class="col-md-12 text-center">
							<div class="col-md-5">
								<?php if($prevs): ?><span>上一篇：</span>
									<a href="/myWeb/index.php/Home/Article/article_detail/id/<?php echo ($prevs["id"]); ?>"><?php echo ($prevs["title"]); ?>&nbsp;&nbsp;</a>
								<?php else: ?>
									<span>上一篇：没有了</span><?php endif; ?>
							</div>
							<div class="col-md-2">
								<a href="/myWeb/index.php/Home/Article/article_list">文章首页</a>
							</div>
							<div class="col-md-5">
								<?php if($nexts): ?><span>&nbsp;&nbsp;下一篇：</span>
									<a href="/myWeb/index.php/Home/Article/article_detail/id/<?php echo ($nexts["id"]); ?>"><?php echo ($nexts["title"]); ?></a>
								<?php else: ?>
									<span>下一篇：没有了</span><?php endif; ?>
							</div>
							<hr />
							<br />
						</div>
						<div class="text-center">
							<h1 class="text-center"><?php echo ($arts["title"]); ?></h1>
							<span>出自：</span><a href="/myWeb/index.php/Home/Article/article_category_list/id/<?php echo ($arts["categoryid"]); ?>"><?php echo ($categoryname); ?></a>
							<span>&nbsp;<?php echo (date("Y-m-d", $arts["time"])); ?></span>
						</div>
						<br />
						<div>
							<?php echo htmlspecialchars_decode($arts['content']); ?>
						</div>
					</div>
					<div class="col-md-2">
						
					</div>
				</div>
				<!--底部-->
				<!--底部-->
<div class="col-md-12">
	<br/>
	<p class="text-center">
		Copyright© 2016 梁峻荣的网站-飘飞的心灵 All Rights Reserved
	</p>
	<p class="icp text-center">
		<a target="_blank" href="http://www.miitbeian.gov.cn">粤ICP备16084737号-1</a>
	</p>
</div>

			</div>
		</div>

		<script src="/myWeb/Public/Js/jquery.min.js"></script>
		<script src="/myWeb/Public/Js/bootstrap.min.js"></script>

	</body>

</html>