<?php
return array(
	//'配置项'=>'配置值'
	
	//自定义success和error的提示页面模板
	'TMPL_ACTION_SUCCESS' => 'Public:dispatch_jump',
	'TMPL_ACTION_ERROR'   => 'Public:dispatch_jump',
);