<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
		<meta name="description" content="飘飞的心灵，祝愿你我，在这个繁忙的世界不迷失自己。">
		<meta name="author" content="梁峻荣">

		<title>梁峻荣的网站-后台管理系统</title>

		<link href="/myWeb/Public/Css/bootstrap.min.css" rel="stylesheet">
		<style>
			.text-indent2{
				text-indent:2em;
			}
		</style>
	</head>

	<body>
		<div class="container">
			<nav class="navbar navbar-default" role="navigation">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">切换导航</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	<a class="navbar-brand" href="#">梁峻荣的网站-后台管理</a></div>
	
	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		<ul class="nav navbar-nav navbar-right">
			<li>
				<a target="_blank" href="/myWeb/index.php/Home/Index/index">网站首页</a>
			</li>
			<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['username']; ?>
					<strong class="caret"></strong>
				</a>
			<ul class="dropdown-menu">
				<li>
					<a href="/myWeb/index.php/Admin/About/index">
						<span class="glyphicon glyphicon-info-sign"></span> 个人资料
					</a>
				</li>
				<li class="divider"></li>
				<li>
					<a href="/myWeb/index.php/Admin/Admin/logout">
						<span class="glyphicon glyphicon-off"></span> 退出
					</a>
				</li>
			</ul>
			</li>
		</ul>
	</div>
</nav>
				<div class="row clearfix">
					<div class="col-md-3 column">
	<div id="list" class="list-group">
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Index/index">首页</a>
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Category/category_list">分类管理</a>
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Article/article_list">文章管理</a>
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Admin/admin_list">管理员管理</a>
		
		<!-- 暂未实现功能 -->
		<a class="list-group-item btn btn-default disabled active" href="#">————————</a>
		<a class="list-group-item btn btn-default disabled" href="#">留言管理</a>
		<a class="list-group-item btn btn-default disabled" href="#">相册管理</a>
		<a class="list-group-item btn btn-default disabled" href="#">文章评论管理</a>
	</div>
	
</div>

					<div class="col-md-9 text-info">
						<h3 class="text-center">我的自学之路</h3>
						<p class="text-indent2">
							你好，欢迎来到►<strong>飘飞的心灵</strong>。
						</p>
						<p class="text-indent2">
							想过很久，建一个网站对我的意义大不大。所以，这个网站，我也搞了很久：从一开始的时候，自己构建有语义化的html架构、搭配合理的样式、写js代码去让它炫酷，后来发觉还有好多东西要我去学去弄，前端这条路真的发展得好快、延伸得好漫长，渐渐地感觉时间好缺好缺，我学的还是好少好少，于是就想着套用bootstrap框架来弄吧，于是就有着现在的网站，目前来说还是静态的，但是我想随着了解点ASP.NET，学习下PHP，我可以把后台也搞搞，弄出一个真正意义上的整站。
						</p>
						<p class="text-indent2">
							一个人，大二开始，就慢慢地琢磨前端的东东，还ok，有时沉迷CSS样式中，学校没有很好的导师，但是网络上的各位前端前辈都是吾师；没有伙伴，但是每一次的自学都使我感到愉悦。从来，没想过后悔，既然做了，就干个漂亮！做最好的自己！
						</p>
						<p class="text-danger text-indent2">
							目前自己自学前端1年多了，如果你有兴趣，可以加我QQ或者微信，一起探讨前端的神奇。
						</p>
						<p class="text-right">
							<span>——2016年11月14日</span>
						</p>
						<div class="col-md-offset-4 col-md-4">
							<img class="img-thumbnail" alt="430x120" src="/myWeb/Public/image/QQ.jpg" />
							<img class="img-thumbnail" alt="430x430" src="/myWeb/Public/image/WeChat.jpg" />
						</div>
					</div>
				</div>
		</div>

		<script src="/myWeb/Public/Js/jquery.min.js"></script>
		<script src="/myWeb/Public/Js/bootstrap.min.js"></script>
	</body>

</html>