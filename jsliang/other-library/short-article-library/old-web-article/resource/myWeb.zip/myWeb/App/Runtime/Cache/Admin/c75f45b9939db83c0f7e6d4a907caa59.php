<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
		<meta name="description" content="飘飞的心灵，祝愿你我，在这个繁忙的世界不迷失自己。">
		<meta name="author" content="梁峻荣">

		<title>梁峻荣的网站-修改管理员</title>

		<link href="/myWeb/Public/Css/bootstrap.min.css" rel="stylesheet">
	</head>

	<body>
		<div class="container">
			<div class="col-md-12 column">
				<nav class="navbar navbar-default" role="navigation">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
			<span class="sr-only">切换导航</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
	<a class="navbar-brand" href="#">梁峻荣的网站-后台管理</a></div>
	
	<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		<ul class="nav navbar-nav navbar-right">
			<li>
				<a target="_blank" href="/myWeb/index.php/Home/Index/index">网站首页</a>
			</li>
			<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					<span class="glyphicon glyphicon-user"></span> <?php echo $_SESSION['username']; ?>
					<strong class="caret"></strong>
				</a>
			<ul class="dropdown-menu">
				<li>
					<a href="/myWeb/index.php/Admin/About/index">
						<span class="glyphicon glyphicon-info-sign"></span> 个人资料
					</a>
				</li>
				<li class="divider"></li>
				<li>
					<a href="/myWeb/index.php/Admin/Admin/logout">
						<span class="glyphicon glyphicon-off"></span> 退出
					</a>
				</li>
			</ul>
			</li>
		</ul>
	</div>
</nav>
				<div class="row clearfix">
					<div class="col-md-3 column">
	<div id="list" class="list-group">
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Index/index">首页</a>
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Category/category_list">文章分类管理</a>
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Article/article_list">文章管理</a>
		<a class="list-group-item btn btn-default" href="/myWeb/index.php/Admin/Admin/admin_list">管理员管理</a>
		
		<!-- 暂未实现功能 -->
		<a class="list-group-item btn btn-default disabled active" href="#">————————</a>
		<a class="list-group-item btn btn-default disabled" href="#">留言管理</a>
		<a class="list-group-item btn btn-default disabled" href="#">相册管理</a>
		<a class="list-group-item btn btn-default disabled" href="#">文章评论管理</a>
	</div>
	
</div>

					<div class="col-md-9 column">
						<ul class="breadcrumb">
							<li>
								<a href="/myWeb/index.php/Admin/Index/index">首页</a>
							</li>
							<li>
								<a href="/myWeb/index.php/Admin/Admin/admin_list">管理员管理</a>
							</li>
							<li class="active">
								修改管理员
							</li>
						</ul>
						<form action="" method="post" id="myform" name="myform">
		                    <input type="hidden" name="id" value="<?php echo ($admins["id"]); ?>" />
		                    <table>
		                        <tbody>
		                            <tr>
		                                <th><i class="text-danger">* </i>管理员名称：</th>
		                                <td>
		                                    <input id="username" name="username" value="<?php echo ($admins["username"]); ?>" type="text" />
		                                </td>
		                            </tr>
		                            <tr>
		                            	<th><br/></th>
		                            	<td><br/></td>
		                            </tr>
		                            <tr>
		                                <th><i class="text-danger">* </i>管理员密码：</th>
		                                <td>
		                                    <input id="password" name="password" value="" type="password" /><span class="text-primary"> 留空则表示不修改</span>
		                                </td>
		                            </tr>
		                            <tr>
		                            	<th><br/></th>
		                            	<td><br/></td>
		                            </tr>
		                            <tr>
		                                <th></th>
		                                <td>
		                                    <input class="btn btn-primary" value="提交" type="submit">
		                                    &nbsp;&nbsp;
		                                    <input class="btn" onclick="history.go(-1)" value="返回" type="button">
		                                </td>
		                            </tr>
		                        </tbody>
		                	</table>
		                </form>
					</div>
				</div>
			</div>
		</div>

		<script src="/myWeb/Public/Js/jquery.min.js"></script>
		<script src="/myWeb/Public/Js/bootstrap.min.js"></script>
	</body>

</html>