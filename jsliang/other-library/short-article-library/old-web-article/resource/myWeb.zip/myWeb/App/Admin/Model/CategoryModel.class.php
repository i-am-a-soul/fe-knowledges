<?php
namespace Admin\Model;
use Think\Model;
class CategoryModel extends Model {
    
    protected $_validate=array(
        array('categoryname', 'require', '栏目名称不得为空！', 1, 'regex',  3), 
        array('categoryname', '',        '栏目名称不得重复！', 1, 'unique', 3), 
   	);
}