<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
		<meta name="description" content="飘飞的心灵，祝愿你我，在这个繁忙的世界不迷失自己。">
		<meta name="author" content="梁峻荣">

		<title>梁峻荣的网站</title>

		<link href="/myWeb/Public/Css/bootstrap.min.css" rel="stylesheet">
	</head>

	<body>
		<div class="container">
			<div class="row">
				<!--导航栏-->
				<div class="navbar navbar-default" role="navigation">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#indexNav">
						 		<span class="sr-only">图标导航</span>
						 		<span class="icon-bar"></span>
						 		<span class="icon-bar"></span>
						 		<span class="icon-bar"></span>
							</button>
						<a class="navbar-brand" href="index.html">飘飞的心灵</a>
					</div>
					<div class="collapse navbar-collapse" id="indexNav">
						<ul class="nav navbar-nav">
							<li>
								<a href="study.html">自学生涯</a>
							</li>
							<li>
								<a href="list.html">书单推荐</a>
							</li>
							<li>
								<a href="about.html">关于网站</a>
							</li>
						</ul>
						<form class="navbar-form navbar-left" action="http://www.baidu.com/baidu" target="_blank">
							<div class="form-group">
								<input type="text" name="word">
							</div>
							<button type="submit" class="btn btn-default">搜索</button>
						</form>
					</div>
				</div>
				<!--内容区-->
				<div class="content col-md-12">
					<!--内容1-->
					<div class="row text-center text-info">
						<h3>飘飞的心灵——活得潇洒</h3>
						<h4>人生三愿：吃得下饭、睡得着觉、笑得出来。</h4>
						<h4>人生四然：来是偶然、去是必然、尽其当然、顺其自然。</h4>
					</div>
					<hr />
					<!--内容2-->
					<div class="row">
						<div class="col-md-4">
							<div class="thumbnail">
								<img alt="200x111" src="/myWeb/Public/home/img/7.jpg" />
								<div class="caption text-center">
									<h3>漫漫前端路</h3>
									<ul class="list-unstyled">
										<li>
											<a href="study/frontEndStudy/reviewArticle4.html">☆压力，镇定，学习，前进！☆</a>
										</li>
										<li>
											<a href="study/frontEndStudy/JavaScript.html">☆JavaScript基础☆</a>
										</li>
										<li>
											<a href="study/frontEndStudy/reviewArticle3.html">☆仿微信心得☆</a>
										</li>
										<li><a href="study/frontEndStudy/reviewArticle2.html">☆论渣渣眼里的“前端脉络图”☆</a></li>
										<li><a href="study/frontEndStudy/reviewArticle1.html">☆前端生涯的从无到有☆</a></li>
										<li><a href="study/jQueryMobile.html">☆jQuery Mobile学习☆</a></li>
									</ul>
									<p><a class="btn btn-primary" href="study.html">入坑瞅瞅</a></p>
								</div>
							</div>
						</div>
						<div class="col-md-4 text-center">
							<div class="thumbnail">
								<img alt="200x111" src="/myWeb/Public/home/img/8.jpg" />
								<div class="caption">
									<h3>悄悄P图心</h3>
									<ul class="list-unstyled">
										<li><a href="#">☆从无到漂亮的月亮☆</a></li>
										<li><a href="#">☆如何将人P上树☆</a></li>
									</ul>
									<p><a class="btn btn-primary" href="study.html">入坑瞅瞅</a></p>
								</div>
							</div>
						</div>
						<div class="col-md-4 text-center">
							<div class="thumbnail">
								<img alt="200x111" src="/myWeb/Public/home/img/9.jpg" />
								<div class="caption">
									<h3>悠悠后台经</h3>
									<ul class="list-unstyled">
										<li><a href="#">☆ASP.NET MVC学习☆</a></li>
										<li><a href="#">☆PHP学习☆</a></li>
									</ul>
									<p><a class="btn btn-primary" href="study.html">入坑瞅瞅</a></p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--底部-->
				<div class="modal-footer">
					<p class="text-center">
						Copyright© 2016 梁峻荣的网站-飘飞的心灵 All Rights Reserved
					</p>
					<p class="icp text-center">
						<a href="http://www.miitbeian.gov.cn">粤ICP备16084737号-1</a>
					</p>
				</div>
			</div>
		</div>

		<script src="/myWeb/Public/Js/jquery.min.js"></script>
		<script src="/myWeb/Public/Js/bootstrap.min.js"></script>

	</body>

</html>