<?php
namespace Admin\Controller;
use Think\Controller;
class CommonController extends Controller {
	//未登录不允许访问其他管理界面
	public function __construct(){
		parent::__construct();
		if(!session('id')){
			$this->error('请先登录系统！', U('Login/index'));
		}
	}
}