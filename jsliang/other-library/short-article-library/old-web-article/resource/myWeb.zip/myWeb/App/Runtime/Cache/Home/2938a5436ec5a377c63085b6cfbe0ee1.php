<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">

	<head>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
		<meta name="description" content="飘飞的心灵，祝愿你我，在这个繁忙的世界不迷失自己。">
		<meta name="author" content="梁峻荣">

		<title>梁峻荣的网站</title>

		<link rel="shortcut icon" type="image/x-icon" href="/myWeb/Public/Image/icon(32).ico" />
		<link href="/myWeb/Public/Css/bootstrap.min.css" rel="stylesheet">
		<style>
			p{
				text-indent: 2em;
			}
		</style>
	</head>

	<body>
		<div class="container">
			<div class="row">
				<!--导航栏-->
<nav class="navbar navbar-default" role="navigation">
	<div class="navbar-header">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#indexNav">
			<span class="sr-only">图标导航</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" href="/myWeb/index.php/Home/Index/index">飘飞的心灵</a>
	</div>

	<div class="collapse navbar-collapse" id="indexNav">
		<ul class="nav navbar-nav">
			<li>
				<a href="/myWeb/index.php/Home/Article/article_list">Study</a>
			</li>
			<li>
				<a href="/myWeb/index.php/Home/About/index">About</a>
			</li>
		</ul>
		<form class="navbar-form navbar-left" action="http://www.baidu.com/baidu" target="_blank">
			<div class="form-group">
				<input type="text" name="word">
			</div>
			<button type="submit" class="btn btn-default">搜索</button>
		</form>
	</div>
</nav>
				
				<!--内容区-->
				<div class="col-md-12 content">
					<div class="col-md-3">
						<h3 class="text-info text-center">学习旅途</h3>
						<div class="list-group">
							<div class="list-group-item active text-center">2017年5月14日</div>
							<div class="list-group-item">
								<p class="list-group-item-text">
									第一次实现“整站”制作
								</p>
							</div>
							
							<div class="list-group-item active text-center">2017年3月</div>
							<div class="list-group-item">
								<p class="list-group-item-text">
									【特训班】
								</p>
								<p class="list-group-item-text">
									蹭PHP课，自学基础php语法、接触ThinkPHP。
								</p>
							</div>
							
							<div class="list-group-item active text-center">2016年11月14日</div>
							<div class="list-group-item">
								<p class="list-group-item-text">
									第一次实现较完整地在云服务器部署静态网站
								</p>
								<p class="list-group-item-text">
									注册域名、购买云服务器、配置IIS、域名备案、上传网站……
								</p>
							</div>
							
							<div class="list-group-item active text-center">2016年9月</div>
							<div class="list-group-item">
								<p class="list-group-item-text">
									必修【WEB系统与技术】
								</p>
								<p class="list-group-item-text">
									接触asp.net，各种蒙蔽，一无所成。
								</p>
							</div>
							
							<div class="list-group-item active text-center">2016年3月</div>
							<div class="list-group-item">
								<p class="list-group-item-text">
									选修【移动互联网UI设计】
								</p>
								<p class="list-group-item-text">
									接触jQuery Mobile，“体验”写APP的感觉。
								</p>
							</div>
							
							<div class="list-group-item active text-center">2015年3月</div>
							<div class="list-group-item">
								<p class="list-group-item-text">
									选修【网页设计基础】
								</p>
								<p class="list-group-item-text">
									首次接触HTML5+CSS3。
								</p>
							</div>
							<div class="list-group-item">
								<p class="list-group-item-text">
									各种自学：HTML5、CSS3、ECMAScript5、bootstrap……
								</p>
							</div>
							
						</div>
					</div>
					<div class="col-md-6 text-info">
						<h3 class="text-center">我的自学之路</h3>
						<p>
							你好，欢迎来到►<strong>飘飞的心灵</strong>。
						</p>
						<p>————2016年11月14日————</p>
						<p>
							想过很久，建一个网站对我的意义大不大。所以，这个网站，我也搞了很久：从一开始的时候，自己构建有语义化的html架构、搭配合理的样式、写js代码去让它炫酷，后来发觉还有好多东西要我去学去弄，前端这条路真的发展得好快、延伸得好漫长，渐渐地感觉时间好缺好缺，我学的还是好少好少，于是就想着套用bootstrap框架来弄吧，于是就有着现在的网站，目前来说还是静态的，但是我想随着了解点ASP.NET，学习下PHP，我可以把后台也搞搞，弄出一个真正意义上的整站。
						</p>
						<p>
							一个人，大二开始，就慢慢地琢磨前端的东东，还ok，有时沉迷CSS样式中，学校没有很好的导师，但是网络上的各位前端前辈都是吾师；没有伙伴，但是每一次的自学都使我感到愉悦。从来，没想过后悔，既然做了，就干个漂亮！做最好的自己！
						</p>
						<p>————2017年5月14日————</p>
						<p>
							很高兴我能接上一次的自我介绍继续写下去。哈哈，是的，我这学期跑去学php了。
						</p>
						<p>
							首先，从0基础开始（php的0基础。如果说后台的话不算，因为上学期我接触过asp.net了，虽然一塌糊涂），开始学php基础，照着书敲敲一些基本php语句（哈，现在也不知道敲了什么了，反正就是敲一遍，理解一遍，懂了，OK，下一份代码）。
						</p>
						<p>
							然后，敲了下基于原生php的MVC框架。没敲完，卡住了（很有意思的，我卡在验证码上你信不？）。
						</p>
						<p>
							再接着，学校特训班的项目老师要求我们小组成员都要投入到php的编写，快速写完项目的功能来。因为我们小组用的是ThinkPHP，所以我乘机跑去自学ThinkPHP咯，平时跟着项目敲敲。然后网上买了个10块钱的教程，照着敲了一遍。接着就是动手，把我原先的静态网站拿过来，分模块，修改。
						</p>
						<p>
							最后，当当当当，我这个没有登录注册、不能留言、不能评论文章……只能后台管理添加文章的整站就出来啦！
						</p>
						<p class="text-danger">————tips————</p>
						<p class="text-danger">
							目前自学2年多了，如果你有兴趣，可以加下我的QQ或者微信，一起探讨前端（HTML5、CSS3、ECMAScript5）以及PHP（ThinkPHP）的神奇。
						</p>
					</div>
					<div class="col-md-3">
						<h3 class="text-info text-center">联系方式</h3>
						<img class="img-thumbnail" alt="430x120" src="/myWeb/Public/Image/QQ.jpg" />
						<img class="img-thumbnail" alt="430x430" src="/myWeb/Public/Image/WeChat.jpg" />
					</div>
				</div>
				<!--底部-->
				<!--底部-->
<div class="col-md-12">
	<br/>
	<p class="text-center">
		Copyright© 2016 梁峻荣的网站-飘飞的心灵 All Rights Reserved
	</p>
	<p class="icp text-center">
		<a target="_blank" href="http://www.miitbeian.gov.cn">粤ICP备16084737号-1</a>
	</p>
</div>

			</div>
		</div>

		<script src="/myWeb/Public/Js/jquery.min.js"></script>
		<script src="/myWeb/Public/Js/bootstrap.min.js"></script>

	</body>

</html>