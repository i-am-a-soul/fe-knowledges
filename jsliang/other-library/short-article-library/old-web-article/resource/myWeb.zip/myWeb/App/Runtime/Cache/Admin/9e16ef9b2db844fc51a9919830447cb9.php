<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
		<meta name="description" content="飘飞的心灵，祝愿你我，在这个繁忙的世界不迷失自己。">
		<meta name="author" content="梁峻荣">

		<title>梁峻荣的网站-登录后台管理系统</title>

		<link rel="shortcut icon" type="image/x-icon" href="/myWeb/Public/Image/icon(32).ico" />
		<link href="/myWeb/Public/Css/bootstrap.min.css" rel="stylesheet">
		<style>
			.list-page{padding:20px 0;text-align:center;}
			.list-page a{margin:0 5px;padding:2px 7px;border:1px solid #ccc;background:#f3f3f3;}
			.list-page a:hover{background:#e4e4e4;border:1px solid #908f8f;}
			.list-page .current{margin:0 5px;padding:2px 7px;background:#f60;border:1px solid #fe8101;color:#fff;}
		</style>
	</head>
	
	<body>
		<div class="container">
			<nav class="navbar navbar-default" role="navigation">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">切换导航</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
				<a class="navbar-brand" href="#">梁峻荣的网站-后台管理登录</a></div>
				
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li>
							<a target="_blank" href="/myWeb/index.php/Home/Index/index">网站首页</a>
						</li>
					</ul>
				</div>
			</nav>
			<div class="row clearfix">
				<div class="col-md-4 column">
				</div>
				<div class="col-md-4 column">
					<h3>
						梁峻荣的网站-后台管理登录界面
					</h3>				
					<div class="thumbnail">
						<br/><br/>
						<form class="form-horizontal" role="form" action="" method="post">
							<div class="form-group">
								 <label for="inputEmail3" class="col-sm-4 control-label">用户名</label>
								<div class="col-sm-6">
									<input type="text" class="form-control" id="username" name="username" />
								</div>
							</div>
							<div class="form-group">
								 <label for="inputPassword3" class="col-sm-4 control-label">密码</label>
								<div class="col-sm-6">
									<input type="password" class="form-control" id="password" name="password" />
								</div>
							</div>
							<div class="form-group">
								 <label for="inputEmail3" class="col-sm-4 control-label">验证码</label>
								<div class="col-sm-6">
									<input type="text" class="form-control" id="verify" name="verify" />
								</div>
								<div class="col-sm-offset-2">
									<img style="cursor:pointer;" onclick="this.src='/myWeb/index.php/Admin/Login/verify/'+Math.random();" src="/myWeb/index.php/Admin/Login/verify" />
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-offset-5 col-sm-7">
									 <button type="submit" class="btn btn-default">登陆</button>
								</div>
							</div>
						</form>
						<br/>
					</div>
				</div>
				<div class="col-md-4 column">
				</div>
			</div>
		</div>
		
		<script src="/myWeb/Public/Js/jquery.min.js"></script>
		<script src="/myWeb/Public/Js/bootstrap.min.js"></script>
	</body>
</html>