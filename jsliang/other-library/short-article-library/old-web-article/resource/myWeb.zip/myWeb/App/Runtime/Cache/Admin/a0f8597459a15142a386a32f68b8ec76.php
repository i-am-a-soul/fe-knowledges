<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1.0, minimum-scale=1.0">
		<meta name="description" content="飘飞的心灵，祝愿你我，在这个繁忙的世界不迷失自己。">
		<meta name="author" content="梁峻荣">

		<title>梁峻荣的网站-后台管理系统</title>

		<link href="/myWeb/Public/Css/bootstrap.min.css" rel="stylesheet">
	</head>

	<body>
		<div class="container">
			<div class="col-md-12 column">
				<nav class="navbar navbar-default" role="navigation">
					<div class="navbar-header">
						<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1"> <span class="sr-only">切换导航</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
						<a class="navbar-brand" href="#">梁峻荣的网站</a>
					</div>

					<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
						<ul class="nav navbar-nav navbar-right">
							<li>
								<a href="#">前往前台首页</a>
							</li>
							<li class="dropdown">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown">用户名<strong class="caret"></strong></a>
								<ul class="dropdown-menu">
									<li>
										<a href="#">个人资料</a>
									</li>
									<li class="divider">
									</li>
									<li>
										<a href="#">退出</a>
									</li>
								</ul>
							</li>
						</ul>
					</div>
				</nav>
				<div class="row clearfix">
					<div class="col-md-3 column">
						<ul class="nav nav-pills nav-stacked">
		                    <li><a href="/myWeb/index.php/Admin/Index/index">首页</a></li>
		                    <li><a href="/myWeb/index.php/Admin/Article/article_list">文章管理</a></li>
		                    <li><a href="/myWeb/index.php/Admin/Category/category_list">分类管理</a></li>
		                    <li><a href="/myWeb/index.php/Admin/Admin/admin_list">管理员管理</a></li>
		               </ul>
					</div>
					<div class="col-md-9 column">
						<div class="list-group">
							<a href="#" class="list-group-item active">Home</a>
							<div class="list-group-item">
								List header
							</div>
							<div class="list-group-item">
								<h4 class="list-group-item-heading">
										List group item heading
									</h4>
								<p class="list-group-item-text">
									...
								</p>
							</div>
							<div class="list-group-item">
								<span class="badge">14</span> Help
							</div>
							<a class="list-group-item active"> <span class="badge">14</span> Help</a>
						</div>
						<table class="table">
							<thead>
								<tr>
									<th>
										编号
									</th>
									<th>
										产品
									</th>
									<th>
										交付时间
									</th>
									<th>
										状态
									</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										1
									</td>
									<td>
										TB - Monthly
									</td>
									<td>
										01/04/2012
									</td>
									<td>
										Default
									</td>
								</tr>
								<tr class="success">
									<td>
										1
									</td>
									<td>
										TB - Monthly
									</td>
									<td>
										01/04/2012
									</td>
									<td>
										Approved
									</td>
								</tr>
								<tr class="error">
									<td>
										2
									</td>
									<td>
										TB - Monthly
									</td>
									<td>
										02/04/2012
									</td>
									<td>
										Declined
									</td>
								</tr>
								<tr class="warning">
									<td>
										3
									</td>
									<td>
										TB - Monthly
									</td>
									<td>
										03/04/2012
									</td>
									<td>
										Pending
									</td>
								</tr>
								<tr class="info">
									<td>
										4
									</td>
									<td>
										TB - Monthly
									</td>
									<td>
										04/04/2012
									</td>
									<td>
										Call in to confirm
									</td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>

		<script src="/myWeb/Public/Js/jquery.min.js"></script>
		<script src="/myWeb/Public/Js/bootstrap.min.js"></script>
	</body>

</html>