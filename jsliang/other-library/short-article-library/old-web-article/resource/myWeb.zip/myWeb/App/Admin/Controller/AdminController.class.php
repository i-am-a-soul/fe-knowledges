<?php
namespace Admin\Controller;
use Think\Controller;
class AdminController extends CommonController {
    public function admin_list(){
    	$admin = D('admin');
    	
    	//分页
    	$count = $admin->count();	//查询满足要求的总记录数
    	$Page = new \Think\Page($count, 2);
    	$show = $Page->show();
    	$list = $admin->order('id asc')->limit($Page->firstRow.','.$Page->listRows)->select();
    	$this->assign('list', $list);	//赋值数据集
		$this->assign('page', $show);	//赋值分页输出
    	
		//排序
		//$adminres = $admin->order('sort asc')->select();
    	//$this->assign('adminres', $adminres);
		
    	$this->display();
    }
	public function admin_add(){
    	$admin = D('admin');
    	if(IS_POST){
    		$data['username'] = I('username');
    		$data['password'] = md5(I('password'));
            if($admin->create($data)){
                if($admin->add()){
                    $this->success('添加管理员成功！',U('admin_list'));
                }else{
                    $this->error('添加管理员失败！');
                }
            }else{
                $this->error($admin->getError());
            }

            return;
    	}
        $this->display();
    }
 	public function admin_edit(){
    	$admin = D('admin');
    	if(IS_POST){
    		$data['username'] = I('username');
    		$data['id'] = I('id');
    		
    		//通过id设置原先账户为$old_admin
    		//然后$old_password就是原先的密码
    		//如果存在提交的密码，则更新并用md5加密
    		//如果没有提交新密码，则使用原先的密码
    		$old_admin = $admin->find($data['id']);
    		$old_password = $old_admin['password'];
    		if(I('password')){
    			$data['password'] = md5(I('password'));
    		}else{
    			$data['password'] = $old_password;
    		}
    		
    		if($admin->create($data)){
    			$save = $admin->save();
    			if($save !== false){
    				$this->success('修改管理员成功！', U('admin_list'));
    			}else{
    				$this->error('修改管理员失败！');
    			}
    		}else{
    			$this->error($admin->getError());
    		}
    		return;
    	}
    	$admins = $admin->find(I('id'));
    	$this->assign('admins', $admins);
 		$this->display();
    }
 	public function admin_delete(){
    	$admin = D('admin');
    	$id = I('id');
    	if($id==1){
    		$this->error('超级管理员不能删除！');
    	}else{
	    	if($admin->delete($id)){
	    		$this->success('删除管理员成功！', U('admin_list'));
	    	}else{
	    		$this->error('删除管理员失败！');
	    	}
    	}
    }
	public function admin_sort(){
    	$admin = D('admin');
    	foreach ($_POST as $id => $sort){
    		$admin->where(array('id'=>$id))->setField('sort', $sort);
    	}
    	$this->success('排序成功！', U('admin_list'));
    }
    
    public function logout(){
    	session(null);	//清空当前的session
    	$this->success('退出成功，跳转中……', U('Login/index'));
    }
}