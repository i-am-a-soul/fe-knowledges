<?php
namespace Home\Controller;
use Think\Controller;
class ArticleCommonController extends Controller{
	public function __construct(){
		parent::__construct();
		$this->article_category();
		$this->category_current();
	}
	//【文章首页】【文章分类页】【文章详细页】文章分类列表
	public function article_category(){
		$category = D('category');
		$categorys = $category->order('sort desc')->select();
		$this->assign('categorys', $categorys);
	}
	
	//【文章首页】【文章分类页】【文章详细页】高亮当前文章分类
	public function category_current(){
    	$current = I('id');	//将用户点击文章分类列表传过来的id获取过来
    	$this->assign('current', $current);	//分配出去实现当前文章分类高亮显示
    }
}