<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
    <head>
    <meta charset=utf-8" />
    <title>跳转提示</title>
    <style>
	    *{ padding: 0; margin: 0; }
	    body{font-family: '微软雅黑'; font-size: 10px; }
	    .message{width: 400px;height: 200px;margin:auto;border:1px solid #1B8F24;margin-top:30px;border-radius:10px;}
	    .head{width: 100%;height: 30px;background: rgb(222,245,194);text-align: center;padding-top: 5px;border-radius:10px;}
	    .content{height: 120px;width: 100%;}
	    .success{color:green;}
	    .error{color:red;}
	    .success ,.error{text-align: center;margin-top: 30px; font-size:30px;}
	    .jump{text-align: center;margin-top: 20px;}
    </style>
    </head>
    
    <body>
	    <div class="message">
	    	<div class="head"><span>☆☆☆温馨提示☆☆☆</span></div>
	    	<div class="content">
		    	<?php if(isset($message)) {?>
		    		<h1 class="success">恭喜，<?php echo($message); ?></h1>
		    	<?php }else{?>
		    		<h1 class="error">抱歉，<?php echo($error); ?></h1>
		    	<?php }?>
		    
		    	<p class="detail"></p>
		    	<p class="jump">
		    		<a id="href" href="<?php echo($jumpUrl); ?>">如果你的浏览器没有自动跳转，请点击这里...</a><br />
					等待时间： <b id="wait"><?php echo($waitSecond); ?></b>
		    	</p>
	    	</div>
	    </div>
	    
	    <script type="text/javascript">
		    (function(){
			    var wait = document.getElementById('wait'),href = document.getElementById('href').href;
			    var interval = setInterval(function(){
				    var time = --wait.innerHTML;
				    if(time <= 0) {
					    location.href = href;
					    clearInterval(interval);
					};
			    }, 1000);
			})();
	    </script>
    </body>
</html>