<?php
namespace Admin\Model;
use Think\Model;
class ArticleModel extends Model {
    
    protected $_validate=array(
        array('title', 'require', '文章标题不得为空！', 1, 'regex', 3), 
        array('categoryid', 'require', '所属栏目不得为空！', 1, 'regex', 3),
        array('content', 'require', '文章内容不得为空！', 1, 'regex', 3), 
   	);
}