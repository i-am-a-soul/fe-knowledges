<?php
namespace Admin\Model;
use Think\Model\ViewModel;
class ArticleViewModel extends ViewModel {
    
    public $viewFields = array(
    	'Article' => array('id', 'title', 'picture', 'time', '_type'=>'LEFT'),
		'Category' => array('categoryname', '_on'=>'Article.categoryid=Category.id'), 	
   	);
}